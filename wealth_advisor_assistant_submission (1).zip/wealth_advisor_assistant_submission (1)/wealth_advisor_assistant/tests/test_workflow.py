import json
import tempfile
import unittest
from pathlib import Path
from wealth_advisor.app import build_orchestrator


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        (self.base / "crm.json").write_text(json.dumps({"clients":{"C1":{"risk_profile":"moderate","financial_goals":["save"]}}}))
        (self.base / "client.json").write_text(json.dumps({"client_id":"C1","currency":"USD","monthly_income":3000,
            "monthly_expenses":2000,"transactions":[{"transaction_id":"T1","date":"2026-01-01","amount":100}]}))

    def tearDown(self):
        self.tmp.cleanup()

    def test_happy_path_and_memory(self):
        client = json.loads((self.base / "client.json").read_text())
        app = build_orchestrator(crm_path=self.base / "crm.json", memory_path=self.base / "memory.json")
        result = app.run(client, review_decision="approve")
        self.assertEqual(result["crm"]["status"], "success")
        self.assertEqual(result["review"]["status"], "approved")
        self.assertTrue((self.base / "memory.json").exists())

    def test_crm_failure_falls_back(self):
        client = json.loads((self.base / "client.json").read_text())
        app = build_orchestrator(crm_path=self.base / "crm.json", memory_path=self.base / "memory.json", crm_fail=True)
        result = app.run(client)
        self.assertEqual(result["crm"]["status"], "unavailable")
        self.assertTrue(result["warnings"])

    def test_missing_required_field_fails(self):
        client = {"client_id":"C1"}
        app = build_orchestrator(crm_path=self.base / "crm.json", memory_path=self.base / "memory.json")
        with self.assertRaisesRegex(ValueError, "Missing required"):
            app.run(client)


if __name__ == "__main__":
    unittest.main()
