import unittest
from wealth_advisor.agents.analyzer import AnalyzerAgent


class AnalyzerTests(unittest.TestCase):
    def setUp(self):
        self.analyzer = AnalyzerAgent()

    def base(self, transactions):
        return {"client_id": "test", "currency": "USD", "monthly_income": 4000,
                "monthly_expenses": 3500, "transactions": transactions,
                "crm_status": "unavailable", "warnings": []}

    def test_large_transaction_is_flagged(self):
        result = self.analyzer.run(self.base([{"transaction_id":"a", "date":"2026-01-01", "amount":2500}]))
        self.assertIn("large_transaction", [a["type"] for a in result["anomalies"]])

    def test_duplicate_id_is_flagged(self):
        tx = {"transaction_id":"same", "date":"2026-01-01", "merchant":"X", "category":"other", "amount":25}
        result = self.analyzer.run(self.base([tx, dict(tx)]))
        self.assertIn("duplicate_transaction_id", [a["type"] for a in result["anomalies"]])
        self.assertIn("possible_duplicate_transaction", [a["type"] for a in result["anomalies"]])

    def test_expenses_exceed_income(self):
        data = self.base([])
        data["monthly_expenses"] = 4500
        result = self.analyzer.run(data)
        self.assertIn("expenses_exceed_income", [a["type"] for a in result["anomalies"]])

    def test_invalid_transaction_amount_does_not_crash(self):
        result = self.analyzer.run(self.base([{"transaction_id":"bad", "amount":"unknown"}]))
        self.assertIn("invalid_amount", [a["type"] for a in result["anomalies"]])

    def test_missing_required_financial_value_fails_clearly(self):
        data = self.base([])
        del data["monthly_income"]
        with self.assertRaisesRegex(ValueError, "monthly_income"):
            self.analyzer.run(data)


if __name__ == "__main__":
    unittest.main()
