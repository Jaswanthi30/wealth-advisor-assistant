from __future__ import annotations
import argparse
import json
import logging
from pathlib import Path
from typing import Any
from wealth_advisor.agents.data_fetcher import DataFetcherAgent
from wealth_advisor.agents.analyzer import AnalyzerAgent
from wealth_advisor.agents.orchestrator import OrchestratorAgent
from wealth_advisor.tools.mock_crm import MockCRMClient
from wealth_advisor.tools.json_memory import JsonMemoryStore


def configure_logging(log_path: str = "logs/wealth_advisor.log", level: str = "INFO") -> None:
    path = Path(log_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=getattr(logging, level.upper(), logging.INFO),
                        format="%(asctime)s %(levelname)s %(name)s %(message)s",
                        handlers=[logging.StreamHandler(), logging.FileHandler(path, encoding="utf-8")],
                        force=True)


def build_orchestrator(*, crm_path: str | Path, memory_path: str | Path, crm_fail: bool = False) -> OrchestratorAgent:
    crm = MockCRMClient(crm_path, fail=crm_fail)
    memory = JsonMemoryStore(memory_path)
    return OrchestratorAgent(DataFetcherAgent(crm), AnalyzerAgent(), memory)


def load_json(path: str | Path) -> dict[str, Any]:
    try:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ValueError(f"Input file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"Input file is not valid JSON: {exc}") from exc
    if not isinstance(payload, dict):
        raise ValueError("Input JSON must contain an object at the top level")
    return payload


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the Wealth Advisor Assistant demo")
    parser.add_argument("--input", default="data/client.json", help="Client financial data JSON file")
    parser.add_argument("--crm", default="data/crm.json", help="Mock CRM JSON file")
    parser.add_argument("--memory", default="data/memory.json", help="Local long-term memory JSON file")
    parser.add_argument("--output", default="output/report.json", help="Report output path")
    parser.add_argument("--review", choices=["pending", "approve", "override"], default="pending",
                        help="Simulate human review decision")
    parser.add_argument("--crm-fail", action="store_true", help="Simulate a CRM API outage")
    parser.add_argument("--log-level", choices=["DEBUG", "INFO", "WARNING", "ERROR"], default="INFO")
    args = parser.parse_args()
    configure_logging(level=args.log_level)
    try:
        client = load_json(args.input)
        orchestrator = build_orchestrator(crm_path=args.crm, memory_path=args.memory, crm_fail=args.crm_fail)
        report = orchestrator.run(client, review_decision=args.review)
        output = Path(args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
        print(json.dumps(report, indent=2, ensure_ascii=False))
        logging.getLogger(__name__).info("Report written to %s", output)
        return 0
    except (ValueError, KeyError, RuntimeError) as exc:
        logging.getLogger(__name__).error("Workflow failed: %s", exc)
        print(json.dumps({"status": "error", "message": str(exc)}, indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
