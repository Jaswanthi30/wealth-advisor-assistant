from __future__ import annotations
from typing import Any, Protocol


class CRMTool(Protocol):
    def get_client_context(self, client_id: str) -> dict[str, Any]: ...


class MemoryTool(Protocol):
    def get_history(self, client_id: str) -> list[dict[str, Any]]: ...
    def save_insight(self, client_id: str, insight: dict[str, Any]) -> None: ...
