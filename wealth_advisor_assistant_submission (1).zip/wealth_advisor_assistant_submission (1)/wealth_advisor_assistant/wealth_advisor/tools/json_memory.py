from __future__ import annotations
import json
import logging
from pathlib import Path
from threading import Lock
from typing import Any

logger = logging.getLogger(__name__)


class JsonMemoryStore:
    """Small local long-term memory store; suitable for a demo, not multi-user production."""
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self._lock = Lock()

    def _read(self) -> dict[str, list[dict[str, Any]]]:
        if not self.path.exists():
            return {}
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            logger.exception("Memory store unreadable; using empty memory for this run")
            return {}

    def get_history(self, client_id: str) -> list[dict[str, Any]]:
        with self._lock:
            return self._read().get(client_id, [])

    def save_insight(self, client_id: str, insight: dict[str, Any]) -> None:
        with self._lock:
            data = self._read()
            data.setdefault(client_id, []).append(insight)
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(self.path.suffix + ".tmp")
            tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
            tmp.replace(self.path)
        logger.info("Saved memory insight for client_id=%s", client_id)
