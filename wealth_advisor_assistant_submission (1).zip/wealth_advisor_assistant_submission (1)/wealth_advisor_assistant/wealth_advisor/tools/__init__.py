"""Tool abstractions and mock implementations."""
