from __future__ import annotations
import json
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class MockCRMClient:
    """Simulated CRM adapter. Replace this class with a real API adapter later."""
    def __init__(self, data_path: str | Path, *, fail: bool = False):
        self.data_path = Path(data_path)
        self.fail = fail

    def get_client_context(self, client_id: str) -> dict[str, Any]:
        logger.info("CRM lookup started for client_id=%s", client_id)
        if self.fail:
            raise ConnectionError("Simulated CRM API outage")
        try:
            payload = json.loads(self.data_path.read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            raise RuntimeError(f"CRM data file not found: {self.data_path}") from exc
        except json.JSONDecodeError as exc:
            raise RuntimeError("CRM data file contains invalid JSON") from exc
        clients = payload.get("clients", {})
        if client_id not in clients:
            raise KeyError(f"No CRM record found for client_id={client_id}")
        return clients[client_id]
