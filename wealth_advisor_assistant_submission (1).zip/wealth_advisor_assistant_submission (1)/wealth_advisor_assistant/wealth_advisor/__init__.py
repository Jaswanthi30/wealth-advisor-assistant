"""Lightweight multi-agent Wealth Advisor Assistant."""
__version__ = "1.0.0"
