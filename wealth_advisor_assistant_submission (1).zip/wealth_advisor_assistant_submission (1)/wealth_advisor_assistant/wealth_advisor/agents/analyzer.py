from __future__ import annotations
import logging
import statistics
from collections import defaultdict
from datetime import date
from typing import Any

logger = logging.getLogger(__name__)


def _number(value: Any, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{field} must be numeric")
    return float(value)


class AnalyzerAgent:
    """Deterministic financial summaries and explainable transaction anomaly checks."""
    def run(self, data: dict[str, Any], history: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        currency = str(data.get("currency", "USD"))
        income = _number(data.get("monthly_income"), "monthly_income")
        expenses = _number(data.get("monthly_expenses"), "monthly_expenses")
        if income < 0 or expenses < 0:
            raise ValueError("monthly_income and monthly_expenses cannot be negative")

        txs = data.get("transactions", [])
        normalized: list[dict[str, Any]] = []
        anomalies: list[dict[str, Any]] = []
        seen_ids: set[str] = set()
        monthly_spend: dict[str, float] = defaultdict(float)
        valid_amounts: list[float] = []

        for index, tx in enumerate(txs):
            if not isinstance(tx, dict):
                anomalies.append({"type": "invalid_transaction", "severity": "medium", "transaction_index": index,
                                  "reason": "Transaction is not a JSON object."})
                continue
            txid = str(tx.get("transaction_id", f"row-{index+1}"))
            try:
                amount = _number(tx.get("amount"), f"transaction {txid} amount")
            except ValueError as exc:
                anomalies.append({"type": "invalid_amount", "severity": "medium", "transaction_id": txid, "reason": str(exc)})
                continue
            if amount < 0:
                anomalies.append({"type": "negative_amount", "severity": "medium", "transaction_id": txid,
                                  "amount": amount, "reason": "Negative transaction amount; confirm refunds/ledger convention."})
            category = str(tx.get("category", "uncategorized"))
            tx_date = str(tx.get("date", "unknown"))
            normalized_tx = {**tx, "transaction_id": txid, "amount": amount, "category": category, "date": tx_date}
            normalized.append(normalized_tx)
            valid_amounts.append(abs(amount))

            if txid in seen_ids:
                anomalies.append({"type": "duplicate_transaction_id", "severity": "high", "transaction_id": txid,
                                  "reason": "Transaction ID appears more than once."})
            seen_ids.add(txid)

            if amount >= max(1000.0, income * 0.5):
                anomalies.append({"type": "large_transaction", "severity": "high" if amount >= income else "medium",
                                  "transaction_id": txid, "amount": amount, "currency": currency,
                                  "reason": "Transaction is at least the larger of 1,000 currency units or 50% of monthly income."})
            if tx_date != "unknown":
                try:
                    month = date.fromisoformat(tx_date[:10]).strftime("%Y-%m")
                    if amount > 0:
                        monthly_spend[month] += amount
                except ValueError:
                    anomalies.append({"type": "invalid_transaction_date", "severity": "low", "transaction_id": txid,
                                      "date": tx_date, "reason": "Date is not ISO-formatted; excluded from monthly trend."})

        # Exact duplicate signature catches repeated records even with different IDs.
        signatures: dict[tuple[Any, ...], list[str]] = defaultdict(list)
        for tx in normalized:
            signatures[(tx.get("date"), tx.get("amount"), tx.get("merchant"), tx.get("category"))].append(tx["transaction_id"])
        for signature, ids in signatures.items():
            if len(ids) > 1:
                anomalies.append({"type": "possible_duplicate_transaction", "severity": "medium", "transaction_ids": ids,
                                  "reason": "Multiple transactions share the same date, amount, merchant, and category; verify before treating as duplicate."})

        months = sorted(monthly_spend)
        monthly_values = [round(monthly_spend[m], 2) for m in months]
        if len(monthly_values) >= 2:
            previous, latest = monthly_values[-2], monthly_values[-1]
            if previous > 0 and latest >= previous * 1.5 and latest - previous >= 500:
                anomalies.append({"type": "monthly_spending_spike", "severity": "medium", "previous_month": months[-2],
                                  "latest_month": months[-1], "previous_spend": previous, "latest_spend": latest,
                                  "reason": "Latest month's recorded positive transactions are at least 50% and 500 currency units above the previous month."})

        savings = income - expenses
        savings_rate = (savings / income * 100.0) if income > 0 else None
        if income == 0:
            anomalies.append({"type": "zero_income", "severity": "medium", "reason": "Monthly income is zero; savings rate cannot be calculated."})
        if expenses > income:
            anomalies.append({"type": "expenses_exceed_income", "severity": "high", "monthly_income": income,
                              "monthly_expenses": expenses, "reason": "Reported monthly expenses exceed reported monthly income."})
        if savings_rate is not None and savings_rate < 10:
            anomalies.append({"type": "low_savings_rate", "severity": "medium", "savings_rate_pct": round(savings_rate, 2),
                              "reason": "Reported savings rate is below the illustrative 10% review threshold."})

        severity_order = {"high": 0, "medium": 1, "low": 2}
        anomalies.sort(key=lambda a: severity_order.get(a.get("severity", "low"), 3))
        recommendations = []
        if expenses > income:
            recommendations.append("Review the largest discretionary expense categories and prepare a realistic cash-flow plan.")
        elif savings_rate is not None and savings_rate < 20:
            recommendations.append("Review recurring expenses and consider a sustainable savings target; confirm goals and obligations first.")
        else:
            recommendations.append("Continue monitoring cash flow and periodically compare actual spending with the budget.")
        if any(a["type"] in {"large_transaction", "possible_duplicate_transaction", "duplicate_transaction_id"} for a in anomalies):
            recommendations.append("Manually verify flagged transactions with source statements before taking action.")
        if any(a["type"] == "monthly_spending_spike" for a in anomalies):
            recommendations.append("Investigate the month-over-month spending increase and check for one-off expenses or data gaps.")

        crm = data.get("crm_context") or {}
        goals = crm.get("financial_goals", []) if isinstance(crm, dict) else []
        result = {
            "client_id": data["client_id"],
            "currency": currency,
            "analysis": {
                "monthly_income": round(income, 2), "reported_monthly_expenses": round(expenses, 2),
                "estimated_monthly_surplus": round(savings, 2),
                "savings_rate_pct": round(savings_rate, 2) if savings_rate is not None else None,
                "transactions_received": len(txs), "transactions_analyzed": len(normalized),
                "monthly_transaction_totals": [{"month": m, "positive_transaction_total": monthly_spend[m]} for m in months],
            },
            "crm": {"status": data.get("crm_status", "unknown"), "risk_profile": crm.get("risk_profile"),
                    "financial_goals": goals},
            "anomalies": anomalies,
            "recommendations": recommendations,
            "memory_context": {"prior_insights_count": len(history or [])},
            "warnings": data.get("warnings", []),
            "disclaimer": "Educational decision support only; not individualized investment, tax, or legal advice. Anomaly flags are signals for review, not proof of fraud.",
        }
        logger.info("Analysis complete for client_id=%s: anomalies=%d", data["client_id"], len(anomalies))
        return result
