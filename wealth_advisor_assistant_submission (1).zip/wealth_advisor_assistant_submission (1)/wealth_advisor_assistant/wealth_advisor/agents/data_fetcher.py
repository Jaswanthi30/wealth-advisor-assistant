from __future__ import annotations
import logging
from typing import Any
from wealth_advisor.tools.interfaces import CRMTool

logger = logging.getLogger(__name__)


class DataFetcherAgent:
    """Validates the client payload and enriches it with optional CRM context."""
    REQUIRED_FIELDS = ("client_id", "currency", "transactions", "monthly_income", "monthly_expenses")

    def __init__(self, crm_tool: CRMTool):
        self.crm_tool = crm_tool

    def run(self, client_data: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(client_data, dict):
            raise ValueError("Client data must be a JSON object")
        missing = [key for key in self.REQUIRED_FIELDS if key not in client_data]
        if missing:
            raise ValueError(f"Missing required client fields: {', '.join(missing)}")
        if not isinstance(client_data["transactions"], list):
            raise ValueError("transactions must be a list")
        if not isinstance(client_data["client_id"], str) or not client_data["client_id"].strip():
            raise ValueError("client_id must be a non-empty string")

        enriched = dict(client_data)
        warnings: list[str] = []
        try:
            enriched["crm_context"] = self.crm_tool.get_client_context(client_data["client_id"])
            enriched["crm_status"] = "success"
        except Exception as exc:  # graceful fallback at the external-tool boundary
            logger.exception("CRM enrichment failed; proceeding without CRM context")
            enriched["crm_context"] = {}
            enriched["crm_status"] = "unavailable"
            warnings.append(f"CRM context unavailable: {type(exc).__name__}. Analysis used client input only.")
        enriched["warnings"] = warnings
        return enriched
