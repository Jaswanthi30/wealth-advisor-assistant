from __future__ import annotations
import logging
from datetime import datetime, timezone
from typing import Any
from wealth_advisor.agents.data_fetcher import DataFetcherAgent
from wealth_advisor.agents.analyzer import AnalyzerAgent
from wealth_advisor.tools.interfaces import MemoryTool

logger = logging.getLogger(__name__)


class OrchestratorAgent:
    """Coordinates data fetching, analysis, optional human review, and memory persistence."""
    def __init__(self, fetcher: DataFetcherAgent, analyzer: AnalyzerAgent, memory: MemoryTool):
        self.fetcher, self.analyzer, self.memory = fetcher, analyzer, memory

    def run(self, client_data: dict[str, Any], *, review_decision: str = "pending") -> dict[str, Any]:
        client_id = client_data.get("client_id", "unknown") if isinstance(client_data, dict) else "unknown"
        logger.info("Workflow started for client_id=%s", client_id)
        enriched = self.fetcher.run(client_data)
        history = self.memory.get_history(enriched["client_id"])
        report = self.analyzer.run(enriched, history)
        report["review"] = {"status": "pending", "reviewer_note": None}
        if review_decision not in {"pending", "approve", "override"}:
            raise ValueError("review_decision must be one of: pending, approve, override")
        if review_decision == "approve":
            report["review"] = {"status": "approved", "reviewer_note": "Approved by human reviewer."}
        elif review_decision == "override":
            report["review"] = {"status": "override_requested", "reviewer_note": "Human review required; no automated recommendation was overridden."}
        report["generated_at"] = datetime.now(timezone.utc).isoformat()
        self.memory.save_insight(enriched["client_id"], {
            "generated_at": report["generated_at"],
            "anomaly_count": len(report["anomalies"]),
            "high_severity_anomaly_count": sum(a.get("severity") == "high" for a in report["anomalies"]),
            "savings_rate_pct": report["analysis"]["savings_rate_pct"],
        })
        logger.info("Workflow completed for client_id=%s review_status=%s", client_id, report["review"]["status"])
        return report
