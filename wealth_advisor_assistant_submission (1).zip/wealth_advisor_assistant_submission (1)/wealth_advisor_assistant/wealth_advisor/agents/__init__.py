"""Specialized agents used by the orchestrator."""
